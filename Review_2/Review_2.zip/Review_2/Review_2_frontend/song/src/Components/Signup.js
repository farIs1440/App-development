import React, { useState } from 'react';
import { ToastContainer, toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import 'react-toastify/dist/ReactToastify.css'; // Import the CSS for react-toastify
import '../styles/signup.css';
import { userRegister } from './api';

function Signup() {
  // const [name, setName] = useState('');
  // const [email, setEmail] = useState('');
  // const [password, setPassword] = useState('');
  const navigate = useNavigate();


  const [signupData, setSignupData] = useState({
    name: '',
    email: '',
    password: '',
});
const handleSignupChange = (e) => {
  setSignupData({ ...signupData, [e.target.name]: e.target.value });
};

  // const handleNameChange = (e) => {
  //   setName(e.target.value);
  // };

  // const handleEmailChange = (e) => {
  //   setEmail(e.target.value);
  // };

  // const handlePasswordChange = (e) => {
  //   setPassword(e.target.value);
  // };

  const handleSubmit = (e) => {
    e.preventDefault();

    // if (!name || !email || !password) {
    //   toast.error('Please fill in all fields.');
    //   return;
    // }

    // Simulate a successful sign-up (Replace this with your actual sign-up logic)
    setTimeout(() => {
      // Replace this with your actual success message
      toast.success('Sign-up successful!');

      userRegister(signupData)
        .then((response) => {
          console.log(response.data);
          console.log(signupData);

          navigate('/login');
        })

      // Redirect to the home page upon successful sign-up
      // Example: history.push('/home');
    }, 300); 
  };

  return (
    <div className='sign1'>
        <ToastContainer />
      <div className="signup-container">
        <h2>Sign Up</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Name:</label>
            <input type="text" name="name" value={signupData.name} onChange={handleSignupChange} />
          </div>
          <div className="form-group">
            <label>Email:</label>
            <input type="email" name="email" value={signupData.email} onChange={handleSignupChange} />
          </div>
          <div className="form-group">
            <label>Password:</label>
            <input type="password" name="password" value={signupData.password} onChange={handleSignupChange} />
          </div>
          <button className='button' type="submit">Sign Up</button>
        </form>
      </div>
    </div>
  );
}

export default Signup;
