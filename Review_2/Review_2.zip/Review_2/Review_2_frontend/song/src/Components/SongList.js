import React, { useState, useEffect } from 'react';
import '../styles/SongList.css'; // Ensure your CSS file path is correct
import { changeTasks, createTask, getTasks, removeTasks } from './api'; // Make sure your API functions are correctly imported

function SongList() {
  const [formState, setFormState] = useState({
    song: '',
    releaseDate: '', // Corrected field name to match your formState
    singer: '',
  });

  const [isInputVisible, setIsInputVisible] = useState(false);
  const [tasks, setTasks] = useState([]);
  const [editingTask, setEditingTask] = useState(null);

  const generateUniqueId = () => {
    return Date.now().toString();
  };

  const fetchTasks = async () => {
    try {
      const response = await getTasks();
      setTasks(response.data);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  const handleFieldChange = (field, value) => {
    setFormState({ ...formState, [field]: value });
  };

  const handleAddTask = async () => {
    const { song, releaseDate, singer } = formState; // Corrected field name to match your formState
    if (song.trim() === '') {
      return;
    }

    if (editingTask) {
      try {
        await changeTasks(editingTask.id, formState);
        const updatedTasks = tasks.map((task) => {
          if (task.id === editingTask.id) {
            return {
              ...task,
              song: formState.song,
              releaseDate: formState.releaseDate, // Corrected field name to match your formState
              singer: formState.singer,
            };
          }
          return task;
        });
        setTasks(updatedTasks);

        setEditingTask(null);
      } catch (error) {
        console.error('Error updating task:', error);
      }
    } else {
      const newTaskId = generateUniqueId();
      const newTask = {
        id: newTaskId,
        song: song,
        releaseDate: releaseDate, // Corrected field name to match your formState
        singer: singer,
      };

      try {
        const response = await createTask(newTask);
        const createdTask = response.data;
        setTasks((prevTasks) => [...prevTasks, createdTask]);
        setFormState({
          song: '',
          releaseDate: '', // Corrected field name to match your formState
          singer: '',
        });
      } catch (error) {
        console.error('Error creating task:', error);
      }
    }

    setIsInputVisible(false);
  };

  const handleToggleInput = () => {
    setIsInputVisible((prevIsInputVisible) => !prevIsInputVisible);
  };

  const handleDeleteTask = async (taskId) => {
    try {
      await removeTasks(taskId);
      const updatedTasks = tasks.filter((task) => task.id !== taskId);
      setTasks(updatedTasks);
    } catch (error) {
      console.error('Error deleting task:', error);
    }
  };

  const handleEdit = async (taskId) => {
    const taskToEdit = tasks.find((task) => task.id === taskId);

    if (taskToEdit) {
      setFormState({
        song: taskToEdit.song,
        releaseDate: taskToEdit.releaseDate, // Corrected field name to match your formState
        singer: taskToEdit.singer,
      });

      setEditingTask(taskToEdit);
    }
  };

  return (
    <div className="taskPage">
      <div className="task-container">
        <div className="task-header">Play List 1</div>
        <span className="task-form">
          {isInputVisible ? (
            <>
              <input
                type="text"
                value={formState.song}
                name="song"
                placeholder="Enter Song name"
                className="Task-inputBox"
                onChange={(e) => handleFieldChange('song', e.target.value)}
              />
              {/* <input
                type="text"
                value={formState.releaseDate}
                name="releaseDate"
                className="Task-inputBox"
                onChange={(e) => handleFieldChange('releaseDate', e.target.value)}
              /> */}
              <input
                type="text"
                value={formState.singer}
                name="singer"
                placeholder="Name of the singer"
                className="Task-inputBox"
                onChange={(e) => handleFieldChange('singer', e.target.value)}
              />
              <button onClick={handleAddTask}>Add Task</button>
            </>
          ) : (
            <svg
              onClick={handleToggleInput}
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="#ff3d3d"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-plus-square"
            >
              <rect width="18" height="18" x="3" y="3" rx="2" />
              <path d="M8 12h8" />
              <path d="M12 8v8" />
            </svg>
          )}
        </span>
        <ul className="task-ul">
          {tasks.map((task) => (
            <li className="task-li" key={task.id}>
              {editingTask && editingTask.id === task.id ? (
                <div className="task-individual">
                  <input
                    type="text"
                    value={formState.song}
                    name="song"
                    className="Task-inputBox"
                    onChange={(e) => handleFieldChange('song', e.target.value)}
                  />
                  {/* <input
                    type="text"
                    value={formState.releaseDate}
                    name="releaseDate"
                    className="Task-inputBox"
                    onChange={(e) => handleFieldChange('releaseDate', e.target.value)}
                  /> */}
                  <input
                    type="text"
                    value={formState.singer}
                    name="singer"
                    className="Task-inputBox"
                    onChange={(e) => handleFieldChange('singer', e.target.value)}
                  />
                  <button onClick={handleAddTask}>Save</button>
                </div>
              ) : (
                <div className="task-individual">
                  <div className="task-description">{task.song}</div>
                  {task.releaseDate && (
                    <div className="task-deadline">Release Date: {task.releaseDate}</div>
                  )}
                  {task.singer && (
                    <div className="task-team-member">Singer: {task.singer}</div>
                  )}
                  <div className="task-actions">
                    <svg
                      onClick={() => handleEdit(task.id)}
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#ed3f3f"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="lucide lucide-pencil"
                    >
                      <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z" />
                      <path d="m15 5 4 4" />
                    </svg>
                    <svg
                      onClick={() => handleDeleteTask(task.id)}
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#ff3d3d"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="lucide lucide-trash-2"
                    >
                      <path d="M3 6h18" />
                      <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                      <path d="M8 6V4c0-1 1-2 2-2h4c1 0-2 1 2 2v2" />
                      <line x1="10" x2="10" y1="11" y2="17" />
                      <line x1="14" x2="14" y1="11" y2="17" />
                    </svg>
                  </div>
                </div>
              )}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default SongList;
