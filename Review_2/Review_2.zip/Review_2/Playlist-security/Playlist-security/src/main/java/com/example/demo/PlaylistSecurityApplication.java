package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlaylistSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlaylistSecurityApplication.class, args);
	}

}
