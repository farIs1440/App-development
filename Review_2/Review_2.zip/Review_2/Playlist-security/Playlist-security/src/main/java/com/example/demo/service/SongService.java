package com.example.demo.service;



	import com.example.demo.dto.request.SongRequest;

	public interface SongService {

	    boolean saveSong(SongRequest request);

	}


